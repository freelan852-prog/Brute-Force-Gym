# Brute Force Gym - Kinetic Engine

A dark, high-contrast, industrial strength gym web application engineered with Vite, React 19, TypeScript, and Tailwind CSS.

## Features
- **Monolithic Athletic Typography**: Barlow Condensed display headers paired with Manrope and tabular numbers.
- **Full-Screen Hero & Telemetry**: Dynamic atmospheric visual backdrop with calibrated platform metrics.
- **Interactive Infrastructure & Armory**: 4 zoned training sectors with IntersectionObserver scroll reveal animations.
- **Membership Commitments**: Monthly, Quarterly (Recommended), and Annual tiers with digital RFID keycard pass generation.
- **Direct Dispatch & Command Center**: Priority intake walkthrough tour scheduler, WhatsApp modal, and directions guide.

---

## Deploying to Vercel

### Option 1: Vercel Dashboard (GitHub / Git)
1. Push this folder to a GitHub, GitLab, or Bitbucket repository.
2. Go to [https://vercel.com/new](https://vercel.com/new) and import the repository.
3. Framework Preset: **Vite** (auto-detected).
4. Build Command: `npm run build`
5. Output Directory: `dist`
6. Click **Deploy**.

### Option 2: Vercel CLI (Direct Deploy)
1. Install Vercel CLI:
   ```bash
   npm i -g vercel
   ```
2. In this project directory, run:
   ```bash
   vercel
   ```
3. Follow the prompts. To deploy directly to production:
   ```bash
   vercel --prod
   ```

---

## Local Development
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the local development server:
   ```bash
   npm run dev
   ```
3. Build for production:
   ```bash
   npm run build
   ```
